package com.csv.path;

public class path {
String folderpath;

@Override
public String toString() {
	return "path [folderpath=" + folderpath + "]";
}

public path(String folderpath) {
	super();
	this.folderpath = folderpath;
}

public path() {
	super();
	// TODO Auto-generated constructor stub
}

public String getFolderpath() {
	return folderpath;
}

public void setFolderpath(String folderpath) {
	this.folderpath = folderpath;
}
}
