package com.csv;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.csv.path.path;

public class ReadCSV {

	private static List<path> readfolderpath(String csvFilePath) {
		List<path> fpath = new ArrayList<>();
		Path pathtofile = Paths.get(csvFilePath);
		try {
			BufferedReader br = Files.newBufferedReader((Path) pathtofile, StandardCharsets.US_ASCII);
			String line = br.readLine();

			String[] attri = line.split("\"");
			path p = createpath(attri);
			fpath.add(p);

		} catch (Exception e) {
			System.out.println("exception occurs");
		}

		return fpath;

	}

	private static path createpath(String[] attri) {
		String name = attri[0];

		return new path(name);
	}

	public static void main(String[] args) {
		String csvFilePath = "C:\\Users\\A200123488\\Desktop\\Practice\\csvFile.csv";
		List<path> fpath = readfolderpath(csvFilePath);
		System.out.println(fpath);

	}

}
